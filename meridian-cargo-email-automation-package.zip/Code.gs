/*******************************************************
 * MERIDIAN CARGO GROUP
 * Google Sheets Shipment Tracking API + Email Automation
 *
 * Required sheets:
 * 1. Shipments
 * 2. TrackingEvents
 *
 * Automatically created when email automation is first used:
 * 3. EmailLog
 *
 * Shipments supports the existing columns plus:
 * CustomerEmail
 *******************************************************/

const CONFIG = {
  SHIPMENTS_SHEET: "Shipments",
  EVENTS_SHEET: "TrackingEvents",
  EMAIL_LOG_SHEET: "EmailLog",

  /* Prefer Script Properties in production. */
  ADMIN_TOKEN: "1234567890asdf1234567890asdf",

  COMPANY_NAME: "Meridian Cargo Group",

  /* Replace with your real customer tracking page URL. */
  TRACKING_URL: "https://YOUR-DOMAIN.com/"
};


/* =====================================================
   BASIC HELPERS
===================================================== */

function getSpreadsheet() {
  return SpreadsheetApp.getActiveSpreadsheet();
}

function getSheet(name) {
  const sheet = getSpreadsheet().getSheetByName(name);
  if (!sheet) throw new Error("Required sheet not found: " + name);
  return sheet;
}

function jsonOutput(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

function normalize(value) {
  return String(value == null ? "" : value).trim();
}

function nowString() {
  return Utilities.formatDate(
    new Date(),
    Session.getScriptTimeZone(),
    "MMMM d, yyyy"
  );
}

function timeString() {
  return Utilities.formatDate(
    new Date(),
    Session.getScriptTimeZone(),
    "HH:mm"
  );
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalize(email));
}

function escapeHtmlEmail(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function trackingUrl(trackingNumber) {
  const base = String(CONFIG.TRACKING_URL || "").trim();
  if (!base || base.indexOf("YOUR-DOMAIN") !== -1) return "";
  const separator = base.indexOf("?") === -1 ? "?" : "&";
  return base + separator + "trackingNumber=" + encodeURIComponent(trackingNumber);
}


/* =====================================================
   ADMIN TOKEN
===================================================== */

function getAdminToken() {
  const propertyToken = PropertiesService
    .getScriptProperties()
    .getProperty("ADMIN_TOKEN");

  if (propertyToken && propertyToken.trim()) return propertyToken.trim();
  return String(CONFIG.ADMIN_TOKEN || "").trim();
}

function verifyAdmin(token) {
  const expectedToken = getAdminToken();
  if (!expectedToken) return false;
  return String(token || "").trim() === expectedToken;
}

function authenticateAdmin(token) {
  if (!verifyAdmin(token)) {
    return { success: false, message: "Invalid administrator token." };
  }
  return {
    success: true,
    message: "Administrator authentication successful."
  };
}


/* =====================================================
   SHEET COLUMN HELPERS
===================================================== */

function getHeaders(sheet) {
  const lastColumn = Math.max(sheet.getLastColumn(), 1);
  return sheet.getRange(1, 1, 1, lastColumn)
    .getValues()[0]
    .map(h => normalize(h));
}

function ensureColumn(sheet, header) {
  let headers = getHeaders(sheet);
  let index = headers.indexOf(header);

  if (index !== -1) return index;

  const newColumn = headers.length + 1;
  sheet.getRange(1, newColumn).setValue(header);
  return newColumn - 1;
}

function ensureEmailInfrastructure() {
  const shipments = getSheet(CONFIG.SHIPMENTS_SHEET);
  ensureColumn(shipments, "CustomerEmail");

  let log = getSpreadsheet().getSheetByName(CONFIG.EMAIL_LOG_SHEET);

  if (!log) {
    log = getSpreadsheet().insertSheet(CONFIG.EMAIL_LOG_SHEET);
    log.appendRow([
      "TrackingNumber",
      "EventKey",
      "SentAt",
      "Recipient",
      "Subject"
    ]);
  }

  return log;
}


/* =====================================================
   FIND SHIPMENT
===================================================== */

function findShipment(trackingNumber) {
  trackingNumber = normalize(trackingNumber).toUpperCase();
  if (!trackingNumber) return null;

  const sheet = getSheet(CONFIG.SHIPMENTS_SHEET);
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return null;

  const headers = values[0].map(h => normalize(h));
  const trackingIndex = headers.indexOf("TrackingNumber");

  if (trackingIndex === -1) {
    throw new Error("TrackingNumber column is missing from Shipments sheet.");
  }

  for (let i = 1; i < values.length; i++) {
    const rowTracking = normalize(values[i][trackingIndex]).toUpperCase();

    if (rowTracking === trackingNumber) {
      const record = {};
      headers.forEach((header, index) => record[header] = values[i][index]);
      record.history = getTrackingHistory(trackingNumber);
      return record;
    }
  }

  return null;
}


/* =====================================================
   TRACKING HISTORY
===================================================== */

function getTrackingHistory(trackingNumber) {
  const sheet = getSheet(CONFIG.EVENTS_SHEET);
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];

  const headers = values[0].map(h => normalize(h));
  const trackingIndex = headers.indexOf("TrackingNumber");
  const dateIndex = headers.indexOf("Date");
  const timeIndex = headers.indexOf("Time");
  const locationIndex = headers.indexOf("Location");
  const statusIndex = headers.indexOf("Status");
  const messageIndex = headers.indexOf("Message");

  if (trackingIndex === -1) {
    throw new Error("TrackingNumber column is missing from TrackingEvents sheet.");
  }

  const history = [];

  for (let i = 1; i < values.length; i++) {
    const rowTracking = normalize(values[i][trackingIndex]).toUpperCase();
    if (rowTracking !== normalize(trackingNumber).toUpperCase()) continue;

    history.push({
      status: statusIndex >= 0 ? normalize(values[i][statusIndex]) : "",
      location: locationIndex >= 0 ? normalize(values[i][locationIndex]) : "",
      message: messageIndex >= 0 ? normalize(values[i][messageIndex]) : "",
      date: dateIndex >= 0 ? formatSheetDate(values[i][dateIndex]) : "",
      time: timeIndex >= 0 ? normalize(values[i][timeIndex]) : ""
    });
  }

  history.reverse();
  return history;
}

function formatSheetDate(value) {
  if (!value) return "";

  if (Object.prototype.toString.call(value) === "[object Date]") {
    return Utilities.formatDate(
      value,
      Session.getScriptTimeZone(),
      "MMMM d, yyyy"
    );
  }

  return normalize(value);
}


/* =====================================================
   PUBLIC GET API
===================================================== */

function doGet(e) {
  try {
    const action = e && e.parameter ? normalize(e.parameter.action) : "";

    if (action === "health") {
      return jsonOutput({
        success: true,
        company: CONFIG.COMPANY_NAME,
        service: "Shipment Tracking API",
        status: "Online"
      });
    }

    if (action === "track" || !action) {
      const trackingNumber = e && e.parameter
        ? normalize(e.parameter.trackingNumber)
        : "";

      if (!trackingNumber) {
        return jsonOutput({
          success: false,
          found: false,
          message: "Tracking number is required."
        });
      }

      const shipment = findShipment(trackingNumber);

      if (!shipment) {
        return jsonOutput({
          success: false,
          found: false,
          message: "Shipment not found."
        });
      }

      return jsonOutput({
        success: true,
        found: true,
        shipment: {
          trackingNumber: shipment.TrackingNumber,
          sender: shipment.Sender,
          recipient: shipment.Recipient,
          origin: shipment.Origin,
          destination: shipment.Destination,
          status: shipment.Status,
          currentLocation: shipment.CurrentLocation,
          estimatedDelivery: shipment.EstimatedDelivery,
          lastUpdated: shipment.LastUpdated,
          description: shipment.Description,
          history: shipment.history
        }
      });
    }

    return jsonOutput({
      success: false,
      message: "Unknown API action."
    });
  } catch (error) {
    return jsonOutput({ success: false, message: error.message });
  }
}


/* =====================================================
   GET ALL SHIPMENTS
===================================================== */

function getAllShipments() {
  const sheet = getSheet(CONFIG.SHIPMENTS_SHEET);
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];

  const headers = values[0].map(h => normalize(h));

  return values.slice(1).map(row => {
    const record = {};
    headers.forEach((header, i) => record[header] = row[i]);

    return {
      trackingNumber: normalize(record.TrackingNumber),
      sender: normalize(record.Sender),
      recipient: normalize(record.Recipient),
      customerEmail: normalize(record.CustomerEmail),
      origin: normalize(record.Origin),
      destination: normalize(record.Destination),
      status: normalize(record.Status),
      currentLocation: normalize(record.CurrentLocation),
      estimatedDelivery: formatSheetDate(record.EstimatedDelivery),
      lastUpdated: formatSheetDate(record.LastUpdated),
      description: normalize(record.Description)
    };
  }).filter(item => item.trackingNumber);
}


/* =====================================================
   EMAIL AUTOMATION
===================================================== */

function emailTemplateKey(status, isCreation) {
  if (isCreation) return "shipment-created";

  const s = normalize(status).toLowerCase();

  if (s === "picked up") return "shipment-picked-up";
  if (s === "in transit") return "in-transit";
  if (s === "customs clearance") return "customs-clearance";
  if (s === "on hold") return "on-hold";
  if (s === "out for delivery") return "out-for-delivery";
  if (s === "delivered") return "delivered";
  if (s === "returned" || s === "cancelled") return "shipment-exception";

  return "shipment-update";
}

function emailSubject(status, trackingNumber, isCreation) {
  const key = emailTemplateKey(status, isCreation);
  const subjects = {
    "shipment-created": "Shipment Created — " + trackingNumber,
    "shipment-picked-up": "Shipment Picked Up — " + trackingNumber,
    "in-transit": "Shipment In Transit — " + trackingNumber,
    "customs-clearance": "Customs Clearance Update — " + trackingNumber,
    "on-hold": "Shipment Update — On Hold — " + trackingNumber,
    "out-for-delivery": "Shipment Out for Delivery — " + trackingNumber,
    "delivered": "Shipment Delivered — " + trackingNumber,
    "shipment-exception": "Important Shipment Update — " + trackingNumber,
    "shipment-update": "Shipment Update — " + trackingNumber
  };
  return subjects[key] || subjects["shipment-update"];
}

function emailHeading(status, isCreation) {
  const key = emailTemplateKey(status, isCreation);
  const headings = {
    "shipment-created": "Your shipment has been registered",
    "shipment-picked-up": "Your shipment has been picked up",
    "in-transit": "Your shipment is in transit",
    "customs-clearance": "Your shipment is undergoing customs clearance",
    "on-hold": "Your shipment is currently on hold",
    "out-for-delivery": "Your shipment is out for delivery",
    "delivered": "Your shipment has been delivered",
    "shipment-exception": "Important update regarding your shipment",
    "shipment-update": "Your shipment has been updated"
  };
  return headings[key] || headings["shipment-update"];
}

function eventMessage(event, status, isCreation) {
  if (normalize(event.message)) return normalize(event.message);

  if (isCreation) return "Your shipment record has been created and is now available for tracking.";

  const s = normalize(status).toLowerCase();
  if (s === "delivered") return "Your shipment has been marked as delivered.";
  if (s === "out for delivery") return "Your shipment is now out for delivery.";
  if (s === "customs clearance") return "Your shipment is currently being processed through customs clearance.";
  if (s === "on hold") return "Your shipment has been placed on hold. Please refer to the latest tracking information below.";
  if (s === "picked up") return "Your shipment has been picked up and entered into the delivery network.";
  if (s === "in transit") return "Your shipment is currently moving through the delivery network.";
  return "Your shipment tracking information has been updated.";
}

function buildEmailHtml(shipment, event, isCreation) {
  const recipient = escapeHtmlEmail(shipment.Recipient || "Customer");
  const tracking = escapeHtmlEmail(shipment.TrackingNumber || "");
  const status = escapeHtmlEmail(shipment.Status || "Updated");
  const origin = escapeHtmlEmail(shipment.Origin || "—");
  const destination = escapeHtmlEmail(shipment.Destination || "—");
  const location = escapeHtmlEmail(event.location || shipment.CurrentLocation || "—");
  const eta = escapeHtmlEmail(shipment.EstimatedDelivery || "To be confirmed");
  const updated = escapeHtmlEmail((event.date || nowString()) + (event.time ? " • " + event.time : ""));
  const message = escapeHtmlEmail(eventMessage(event, shipment.Status, isCreation));
  const url = trackingUrl(shipment.TrackingNumber);
  const button = url
    ? '<a href="' + escapeHtmlEmail(url) + '" style="display:inline-block;background:#0b1f35;color:#ffffff;text-decoration:none;padding:14px 22px;border-radius:7px;font-size:13px;font-weight:700;">Track Shipment</a>'
    : '<span style="display:inline-block;background:#0b1f35;color:#ffffff;padding:14px 22px;border-radius:7px;font-size:13px;font-weight:700;">Track Shipment</span>';

  return '<!doctype html>' +
    '<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"></head>' +
    '<body style="margin:0;background:#f3f6f9;font-family:Arial,Helvetica,sans-serif;color:#172033;">' +
    '<div style="max-width:680px;margin:30px auto;padding:0 14px;">' +
    '<div style="background:#071a2e;border-radius:14px 14px 0 0;padding:25px 28px;">' +
    '<div style="font-size:19px;font-weight:800;color:#ffffff;letter-spacing:.3px;">MERIDIAN CARGO GROUP</div>' +
    '<div style="font-size:9px;color:#c9a44c;letter-spacing:2px;margin-top:5px;text-transform:uppercase;">Global Logistics & Shipment Tracking</div>' +
    '</div>' +
    '<div style="background:#ffffff;padding:34px 30px;border:1px solid #e5eaf0;border-top:0;">' +
    '<div style="font-size:11px;color:#b18b38;font-weight:800;letter-spacing:1.7px;text-transform:uppercase;">Shipment Notification</div>' +
    '<h1 style="font-family:Georgia,serif;font-size:28px;line-height:1.2;color:#071a2e;margin:10px 0 0;">' + emailHeading(shipment.Status, isCreation) + '</h1>' +
    '<p style="font-size:14px;line-height:1.7;color:#667085;margin:16px 0 0;">Dear ' + recipient + ',<br><br>' + message + '</p>' +
    '<div style="margin:26px 0;padding:18px;background:#f7f9fb;border:1px solid #e4eaf0;border-radius:10px;">' +
    '<div style="font-size:10px;color:#7a8796;text-transform:uppercase;letter-spacing:1px;font-weight:800;">Current Status</div>' +
    '<div style="margin-top:8px;font-size:18px;font-weight:800;color:#071a2e;">' + status + '</div>' +
    '<div style="margin-top:7px;font-size:12px;color:#667085;">Latest update: ' + updated + '</div>' +
    '</div>' +
    '<table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;font-size:13px;">' +
    '<tr><td style="padding:10px 0;color:#7a8796;width:42%;border-bottom:1px solid #edf1f5;">Tracking Number</td><td style="padding:10px 0;font-weight:800;border-bottom:1px solid #edf1f5;">' + tracking + '</td></tr>' +
    '<tr><td style="padding:10px 0;color:#7a8796;border-bottom:1px solid #edf1f5;">Origin</td><td style="padding:10px 0;border-bottom:1px solid #edf1f5;">' + origin + '</td></tr>' +
    '<tr><td style="padding:10px 0;color:#7a8796;border-bottom:1px solid #edf1f5;">Destination</td><td style="padding:10px 0;border-bottom:1px solid #edf1f5;">' + destination + '</td></tr>' +
    '<tr><td style="padding:10px 0;color:#7a8796;border-bottom:1px solid #edf1f5;">Current Location</td><td style="padding:10px 0;border-bottom:1px solid #edf1f5;">' + location + '</td></tr>' +
    '<tr><td style="padding:10px 0;color:#7a8796;">Estimated Delivery</td><td style="padding:10px 0;font-weight:700;">' + eta + '</td></tr>' +
    '</table>' +
    '<div style="margin-top:28px;text-align:center;">' + button + '</div>' +
    '<div style="margin-top:30px;padding-top:20px;border-top:1px solid #e7edf2;font-size:11px;line-height:1.6;color:#7a8796;">This is an automated shipment notification from Meridian Cargo Group. Please keep your tracking number for future reference.</div>' +
    '</div>' +
    '<div style="text-align:center;padding:18px 10px;font-size:10px;color:#8793a2;">© ' + new Date().getFullYear() + ' Meridian Cargo Group. All rights reserved.</div>' +
    '</div></body></html>';
}

function emailAlreadySent(eventKey) {
  const log = ensureEmailInfrastructure();
  const values = log.getDataRange().getValues();
  if (values.length < 2) return false;

  for (let i = 1; i < values.length; i++) {
    if (normalize(values[i][1]) === normalize(eventKey)) return true;
  }
  return false;
}

function logEmail(trackingNumber, eventKey, recipient, subject) {
  const log = ensureEmailInfrastructure();
  log.appendRow([
    trackingNumber,
    eventKey,
    new Date(),
    recipient,
    subject
  ]);
}

function sendShipmentEmail(shipment, event, isCreation, eventKey) {
  const recipient = normalize(shipment.CustomerEmail);

  if (!isValidEmail(recipient)) {
    return {
      sent: false,
      skipped: true,
      reason: "No valid customer email address was provided."
    };
  }

  if (emailAlreadySent(eventKey)) {
    return {
      sent: false,
      skipped: true,
      reason: "This notification has already been sent."
    };
  }

  const subject = emailSubject(shipment.Status, shipment.TrackingNumber, isCreation);
  const htmlBody = buildEmailHtml(shipment, event, isCreation);
  const plainBody =
    "Meridian Cargo Group\n\n" +
    emailHeading(shipment.Status, isCreation) + "\n\n" +
    eventMessage(event, shipment.Status, isCreation) + "\n\n" +
    "Tracking Number: " + shipment.TrackingNumber + "\n" +
    "Status: " + shipment.Status + "\n" +
    "Current Location: " + (event.location || shipment.CurrentLocation || "—") + "\n" +
    "Estimated Delivery: " + (shipment.EstimatedDelivery || "To be confirmed") +
    (trackingUrl(shipment.TrackingNumber) ? "\n\nTrack: " + trackingUrl(shipment.TrackingNumber) : "");

  MailApp.sendEmail({
    to: recipient,
    subject: subject,
    body: plainBody,
    htmlBody: htmlBody,
    name: CONFIG.COMPANY_NAME
  });

  logEmail(shipment.TrackingNumber, eventKey, recipient, subject);

  return { sent: true, recipient: recipient, subject: subject };
}

function notifyShipmentEvent(trackingNumber, event, isCreation, eventRow) {
  const shipment = findShipment(trackingNumber);
  if (!shipment) return { sent: false, skipped: true, reason: "Shipment not found." };

  const key = "tracking-event-row:" + String(eventRow);
  return sendShipmentEmail(shipment, event, !!isCreation, key);
}


/* =====================================================
   CREATE SHIPMENT
===================================================== */

function createShipment(data) {
  if (!verifyAdmin(data.token)) throw new Error("Unauthorized.");

  const sheet = getSheet(CONFIG.SHIPMENTS_SHEET);
  const trackingNumber = normalize(data.trackingNumber).toUpperCase();
  if (!trackingNumber) throw new Error("Tracking number is required.");
  if (findShipment(trackingNumber)) {
    throw new Error("A shipment with this tracking number already exists.");
  }

  ensureColumn(sheet, "CustomerEmail");
  const headers = getHeaders(sheet);
  const row = new Array(headers.length).fill("");
  const values = {
    TrackingNumber: trackingNumber,
    Sender: normalize(data.sender),
    Recipient: normalize(data.recipient),
    CustomerEmail: normalize(data.customerEmail),
    Origin: normalize(data.origin),
    Destination: normalize(data.destination),
    Status: normalize(data.status) || "Processing",
    CurrentLocation: normalize(data.currentLocation),
    EstimatedDelivery: normalize(data.estimatedDelivery),
    LastUpdated: normalize(data.lastUpdated) || nowString(),
    Description: normalize(data.description)
  };

  headers.forEach((header, i) => {
    if (Object.prototype.hasOwnProperty.call(values, header)) row[i] = values[header];
  });
  sheet.appendRow(row);

  const event = {
    trackingNumber: trackingNumber,
    location: values.CurrentLocation,
    status: values.Status,
    message: "Shipment created."
  };

  const eventResult = addTrackingEvent({
    token: data.token,
    trackingNumber: trackingNumber,
    location: event.location,
    status: event.status,
    message: event.message
  });

  const emailResult = notifyShipmentEvent(
    trackingNumber,
    {
      location: event.location,
      status: event.status,
      message: event.message,
      date: eventResult.date,
      time: eventResult.time
    },
    true,
    eventResult.rowNumber
  );

  return {
    success: true,
    message: "Shipment created successfully.",
    trackingNumber: trackingNumber,
    email: emailResult
  };
}


/* =====================================================
   UPDATE SHIPMENT
===================================================== */

function updateShipment(data) {
  if (!verifyAdmin(data.token)) throw new Error("Unauthorized.");

  const trackingNumber = normalize(data.trackingNumber).toUpperCase();
  if (!trackingNumber) throw new Error("Tracking number is required.");

  const sheet = getSheet(CONFIG.SHIPMENTS_SHEET);
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) throw new Error("No shipment records exist.");

  const headers = values[0].map(h => normalize(h));
  const trackingIndex = headers.indexOf("TrackingNumber");
  if (trackingIndex === -1) throw new Error("TrackingNumber column missing.");

  let rowNumber = -1;
  let oldStatus = "";
  let oldEmail = "";

  for (let i = 1; i < values.length; i++) {
    if (normalize(values[i][trackingIndex]).toUpperCase() === trackingNumber) {
      rowNumber = i + 1;
      oldStatus = normalize(values[i][headers.indexOf("Status")]);
      const emailIndex = headers.indexOf("CustomerEmail");
      oldEmail = emailIndex >= 0 ? normalize(values[i][emailIndex]) : "";
      break;
    }
  }

  if (rowNumber === -1) throw new Error("Shipment not found.");

  ensureColumn(sheet, "CustomerEmail");
  const refreshedHeaders = getHeaders(sheet);
  const status = normalize(data.status) || "Processing";
  const location = normalize(data.currentLocation);
  const customerEmail = Object.prototype.hasOwnProperty.call(data, "customerEmail")
    ? normalize(data.customerEmail)
    : oldEmail;

  setCellByHeader(sheet, refreshedHeaders, rowNumber, "Sender", data.sender);
  setCellByHeader(sheet, refreshedHeaders, rowNumber, "Recipient", data.recipient);
  setCellByHeader(sheet, refreshedHeaders, rowNumber, "CustomerEmail", customerEmail);
  setCellByHeader(sheet, refreshedHeaders, rowNumber, "Origin", data.origin);
  setCellByHeader(sheet, refreshedHeaders, rowNumber, "Destination", data.destination);
  setCellByHeader(sheet, refreshedHeaders, rowNumber, "Status", status);
  setCellByHeader(sheet, refreshedHeaders, rowNumber, "CurrentLocation", location);
  setCellByHeader(sheet, refreshedHeaders, rowNumber, "EstimatedDelivery", data.estimatedDelivery);
  setCellByHeader(sheet, refreshedHeaders, rowNumber, "LastUpdated", nowString());
  setCellByHeader(sheet, refreshedHeaders, rowNumber, "Description", data.description);

  const message = normalize(data.message) || "Shipment status updated.";

  const eventResult = addTrackingEvent({
    token: data.token,
    trackingNumber: trackingNumber,
    location: location,
    status: status,
    message: message
  });

  const emailResult = notifyShipmentEvent(
    trackingNumber,
    {
      location: location,
      status: status,
      message: message,
      date: eventResult.date,
      time: eventResult.time
    },
    false,
    eventResult.rowNumber
  );

  return {
    success: true,
    message: "Shipment updated successfully.",
    email: emailResult,
    statusChanged: oldStatus !== status
  };
}


/* =====================================================
   SET CELL
===================================================== */

function setCellByHeader(sheet, headers, rowNumber, header, value) {
  const index = headers.indexOf(header);
  if (index === -1) return;
  sheet.getRange(rowNumber, index + 1).setValue(normalize(value));
}


/* =====================================================
   ADD TRACKING EVENT
===================================================== */

function addTrackingEvent(data) {
  if (!verifyAdmin(data.token)) throw new Error("Unauthorized.");

  const sheet = getSheet(CONFIG.EVENTS_SHEET);
  const date = nowString();
  const time = timeString();

  sheet.appendRow([
    normalize(data.trackingNumber).toUpperCase(),
    date,
    time,
    normalize(data.location),
    normalize(data.status),
    normalize(data.message)
  ]);

  const rowNumber = sheet.getLastRow();

  return {
    success: true,
    rowNumber: rowNumber,
    date: date,
    time: time
  };
}


/* =====================================================
   DELETE SHIPMENT
===================================================== */

function deleteShipment(data) {
  if (!verifyAdmin(data.token)) throw new Error("Unauthorized.");

  const trackingNumber = normalize(data.trackingNumber).toUpperCase();
  const sheet = getSheet(CONFIG.SHIPMENTS_SHEET);
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) throw new Error("No shipment records exist.");

  const headers = values[0].map(h => normalize(h));
  const trackingIndex = headers.indexOf("TrackingNumber");
  if (trackingIndex === -1) throw new Error("TrackingNumber column missing.");

  for (let i = values.length - 1; i >= 1; i--) {
    if (normalize(values[i][trackingIndex]).toUpperCase() === trackingNumber) {
      sheet.deleteRow(i + 1);
      return { success: true, message: "Shipment deleted." };
    }
  }

  throw new Error("Shipment not found.");
}


/* =====================================================
   ADMIN POST API
===================================================== */

function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) {
      return jsonOutput({ success: false, message: "No request data received." });
    }

    const data = JSON.parse(e.postData.contents);
    const action = normalize(data.action);

    if (action === "authenticate") {
      return jsonOutput(authenticateAdmin(data.token));
    }

    if (action === "list") {
      if (!verifyAdmin(data.token)) {
        return jsonOutput({ success: false, message: "Unauthorized." });
      }
      return jsonOutput({ success: true, shipments: getAllShipments() });
    }

    if (action === "get") {
      if (!verifyAdmin(data.token)) {
        return jsonOutput({ success: false, message: "Unauthorized." });
      }

      const trackingNumber = normalize(data.trackingNumber);
      const shipment = findShipment(trackingNumber);
      if (!shipment) {
        return jsonOutput({ success: false, message: "Shipment not found." });
      }

      return jsonOutput({
        success: true,
        shipment: shipment,
        history: getTrackingHistory(trackingNumber)
      });
    }

    if (!verifyAdmin(data.token)) {
      return jsonOutput({ success: false, message: "Unauthorized." });
    }

    if (action === "create") return jsonOutput(createShipment(data));
    if (action === "update") return jsonOutput(updateShipment(data));

    if (action === "event") {
      const result = addTrackingEvent(data);
      const trackingNumber = normalize(data.trackingNumber).toUpperCase();
      const emailResult = notifyShipmentEvent(
        trackingNumber,
        {
          location: normalize(data.location),
          status: normalize(data.status),
          message: normalize(data.message),
          date: result.date,
          time: result.time
        },
        false,
        result.rowNumber
      );

      return jsonOutput({
        success: true,
        message: "Tracking event added successfully.",
        email: emailResult
      });
    }

    if (action === "delete") return jsonOutput(deleteShipment(data));

    return jsonOutput({ success: false, message: "Unknown API action." });
  } catch (error) {
    return jsonOutput({ success: false, message: error.message });
  }
}
